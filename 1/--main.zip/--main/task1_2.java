public class С2 {
    public static void main(String[] args){
        boolean a = true;
        char b = 'v';
        byte c = 8;
        short d = 20000;
        int e = 10;
        long f = 89000;
        double j = 65.986538984594;
    }
}
